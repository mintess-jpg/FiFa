plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mintess.fifa"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mintess.fifa"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Sabit imza: bütün gələcək build-lər eyni açarla imzalanır,
    // ona görə yeni versiyalar köhnənin üstünə silmədən yüklənir.
    // DİQQƏT: fifa.jks faylını itirməyin — o olmadan yeniləmə mümkün deyil.
    signingConfigs {
        create("fifa") {
            storeFile = file("fifa.jks")
            storePassword = "mintess2026"
            keyAlias = "fifa"
            keyPassword = "mintess2026"
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fifa")
        }
        release {
            isMinifyEnabled = false
            isDebuggable = false
            signingConfig = signingConfigs.getByName("fifa")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
