package com.mintess.fifa

import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.File
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.tanh

/**
 * Faylı özü decode edib AudioTrack ilə oxudan pleyer.
 * Boost proqram daxilində tətbiq olunur (gain + yumşaq limiter), ona görə
 * maşının audio effektləri dəstəkləməsindən asılı deyil və sistemin maksimum
 * səsindən də yüksək eşidilir.
 */
class BoostPlayer(
    private val file: File,
    private val attributes: AudioAttributes,
    private val device: AudioDeviceInfo?,
    @Volatile var looping: Boolean,
    boostDb: Float,
    private val onProgress: (posMs: Long, durMs: Long) -> Unit,
    private val onFinished: (error: String?) -> Unit
) {
    @Volatile private var running = true
    @Volatile private var gain = dbToGain(boostDb)
    @Volatile var routedOk: Boolean = true
        private set

    private val main = Handler(Looper.getMainLooper())
    private var thread: Thread? = null
    @Volatile private var track: AudioTrack? = null
    private var framesWritten = 0L
    private var channels = 2

    fun setBoostDb(db: Float) { gain = dbToGain(db) }

    fun start() {
        thread = Thread({ runLoop() }, "FiFa-player").also { it.start() }
    }

    /** İstifadəçi dayandırdı — onFinished çağırılmır. */
    fun stop() {
        running = false
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        try { thread?.join(800) } catch (_: Exception) {}
    }

    private fun dbToGain(db: Float) = 10f.pow(db.coerceAtLeast(0f) / 20f)

    private fun runLoop() {
        var extractor: MediaExtractor? = null
        var codec: MediaCodec? = null
        var error: String? = null
        var naturalEnd = false
        try {
            val ex = MediaExtractor().also { extractor = it }
            ex.setDataSource(file.absolutePath)
            var trackIndex = -1
            var inFormat: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    trackIndex = i; inFormat = f; break
                }
            }
            if (trackIndex < 0 || inFormat == null) throw IllegalStateException("Faylda audio tapılmadı")
            ex.selectTrack(trackIndex)
            val durUs = if (inFormat.containsKey(MediaFormat.KEY_DURATION)) inFormat.getLong(MediaFormat.KEY_DURATION) else 0L

            val mime = inFormat.getString(MediaFormat.KEY_MIME)!!
            val dec = MediaCodec.createDecoderByType(mime).also { codec = it }
            dec.configure(inFormat, null, null, 0)
            dec.start()

            val info = MediaCodec.BufferInfo()
            var inputEos = false
            var outFormat: MediaFormat = inFormat
            var lastUi = 0L
            var shorts = ShortArray(0)

            while (running) {
                if (!inputEos) {
                    val inIdx = dec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = dec.getInputBuffer(inIdx)!!
                        var size = ex.readSampleData(buf, 0)
                        if (size < 0 && looping) {
                            ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                            size = ex.readSampleData(buf, 0)
                        }
                        if (size < 0) {
                            dec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEos = true
                        } else {
                            dec.queueInputBuffer(inIdx, 0, size, ex.sampleTime.coerceAtLeast(0L), 0)
                            ex.advance()
                        }
                    }
                }

                val outIdx = dec.dequeueOutputBuffer(info, 10_000)
                when {
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        outFormat = dec.outputFormat
                        releaseTrack()
                    }
                    outIdx >= 0 -> {
                        val out = dec.getOutputBuffer(outIdx)
                        if (out != null && info.size > 0) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val t = track ?: createTrack(outFormat)
                            val isFloat = Build.VERSION.SDK_INT >= 24 &&
                                outFormat.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                                outFormat.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                            val n: Int
                            if (isFloat) {
                                val fb = out.order(ByteOrder.nativeOrder()).asFloatBuffer()
                                n = fb.remaining()
                                if (shorts.size < n) shorts = ShortArray(n)
                                val g = gain
                                for (i in 0 until n) shorts[i] = limit(fb.get(i) * g)
                            } else {
                                val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                                n = sb.remaining()
                                if (shorts.size < n) shorts = ShortArray(n)
                                val g = gain
                                for (i in 0 until n) shorts[i] = limit(sb.get(i) / 32768f * g)
                            }
                            var off = 0
                            while (off < n && running) {
                                val w = t.write(shorts, off, n - off)
                                if (w <= 0) break
                                off += w
                                framesWritten += (w / channels).toLong()
                            }
                            val now = System.currentTimeMillis()
                            if (now - lastUi > 250 && durUs > 0) {
                                lastUi = now
                                val pos = (info.presentationTimeUs / 1000)
                                main.post { onProgress(pos, durUs / 1000) }
                            }
                        }
                        dec.releaseOutputBuffer(outIdx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            naturalEnd = true
                            break
                        }
                    }
                }
            }
            if (naturalEnd) drainTrack()
        } catch (e: Exception) {
            error = e.message ?: e.javaClass.simpleName
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { extractor?.release() } catch (_: Exception) {}
            releaseTrack()
        }
        if (running) {
            running = false
            main.post { onFinished(error) }
        }
    }

    /** Gain + yumşaq limiter: səs gücləndirilir, amma kəskin xırıltı əvəzinə yumşaq sıxılır. */
    private fun limit(x: Float): Short {
        val knee = 0.75f
        val a = abs(x)
        val y = if (a <= knee) a else knee + (1f - knee) * tanh((a - knee) / (1f - knee))
        val s = if (x < 0) -y else y
        return (s * 32767f).toInt().coerceIn(-32768, 32767).toShort()
    }

    private fun createTrack(fmt: MediaFormat): AudioTrack {
        val rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val mask = when (ch) {
            1 -> AudioFormat.CHANNEL_OUT_MONO
            2 -> AudioFormat.CHANNEL_OUT_STEREO
            else -> throw IllegalStateException("$ch kanallı audio dəstəklənmir")
        }
        val minBuf = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(attributes)
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setChannelMask(mask)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes((minBuf * 2).coerceAtLeast(rate * ch * 2 / 5))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        if (device != null) routedOk = t.setPreferredDevice(device)
        channels = ch
        framesWritten = 0L
        t.play()
        track = t
        return t
    }

    /** Təbii sonda buferdə qalan səsin axıra qədər çalınmasını gözləyir. */
    private fun drainTrack() {
        val t = track ?: return
        try {
            val deadline = System.currentTimeMillis() + 3000
            while (running && System.currentTimeMillis() < deadline &&
                (t.playbackHeadPosition.toLong() and 0xFFFFFFFFL) < framesWritten) {
                Thread.sleep(40)
            }
        } catch (_: Exception) {}
    }

    private fun releaseTrack() {
        val t = track ?: return
        track = null
        try { t.pause() } catch (_: Exception) {}
        try { t.flush() } catch (_: Exception) {}
        try { t.release() } catch (_: Exception) {}
    }
}
