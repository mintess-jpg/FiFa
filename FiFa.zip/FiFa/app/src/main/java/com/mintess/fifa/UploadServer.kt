package com.mintess.fifa

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/**
 * Çox sadə HTTP yükləmə serveri (kənar kitabxana yoxdur).
 * Telefondan brauzerdə http://<maşının-ip>:8080 açıb PIN yazırsan, mp3 seçib yükləyirsən.
 * Fayllar `dir` qovluğuna düşür və proqramın siyahısında görünür.
 */
class UploadServer(
    private val dir: File,
    private val pin: String,
    private val onChange: () -> Unit
) {
    private var server: ServerSocket? = null
    private val maxBytes = 40 * 1024 * 1024 // 40 MB
    private val allowedExt = setOf("mp3", "wav", "ogg", "m4a", "aac")

    fun start(port: Int = 8080) {
        if (server != null) return
        val s = ServerSocket(port)
        server = s
        thread(isDaemon = true) {
            while (!s.isClosed) {
                try {
                    val c = s.accept()
                    thread(isDaemon = true) { handle(c) }
                } catch (_: Exception) {
                    break
                }
            }
        }
    }

    fun stop() {
        try { server?.close() } catch (_: Exception) {}
        server = null
    }

    val running: Boolean get() = server != null

    private fun handle(sock: Socket) {
        sock.use { s ->
            try {
                s.soTimeout = 15000
                val input = s.getInputStream()
                val out = s.getOutputStream()
                val head = readHeaders(input) ?: return
                val lines = head.split("\r\n")
                val reqLine = lines.firstOrNull()?.split(" ") ?: return
                if (reqLine.size < 2) return
                val method = reqLine[0]
                val path = reqLine[1].substringBefore('?')
                val headers = HashMap<String, String>()
                for (l in lines.drop(1)) {
                    val i = l.indexOf(':')
                    if (i > 0) headers[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim()
                }
                if (method == "GET" && path == "/") {
                    respond(out, 200, page(""))
                } else if (method == "POST" && path == "/upload") {
                    val len = headers["content-length"]?.toLongOrNull() ?: -1
                    val ctype = headers["content-type"] ?: ""
                    val boundary = ctype.substringAfter("boundary=", "").trim().trim('"')
                    if (len <= 0 || len > maxBytes || boundary.isEmpty()) {
                        respond(out, 400, page("Fayl çox böyükdür və ya düzgün deyil (maks 40 MB)."))
                        return
                    }
                    val body = readBody(input, len.toInt())
                    val msg = parseMultipart(body, boundary)
                    respond(out, 200, page(msg))
                } else {
                    respond(out, 404, page("Tapılmadı."))
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun readHeaders(input: InputStream): String? {
        val buf = ByteArrayOutputStream()
        var last4 = 0
        while (buf.size() < 16384) {
            val b = input.read()
            if (b < 0) return null
            buf.write(b)
            last4 = (last4 shl 8) or b
            if (last4 == 0x0D0A0D0A) break
        }
        return buf.toString("ISO-8859-1").trimEnd()
    }

    private fun readBody(input: InputStream, len: Int): ByteArray {
        val data = ByteArray(len)
        var off = 0
        while (off < len) {
            val n = input.read(data, off, len - off)
            if (n < 0) break
            off += n
        }
        return if (off == len) data else data.copyOf(off)
    }

    private fun indexOf(h: ByteArray, n: ByteArray, from: Int): Int {
        if (n.isEmpty()) return -1
        outer@ for (i in from..h.size - n.size) {
            for (j in n.indices) if (h[i + j] != n[j]) continue@outer
            return i
        }
        return -1
    }

    private fun parseMultipart(body: ByteArray, boundary: String): String {
        val delim = ("--$boundary").toByteArray(Charsets.ISO_8859_1)
        val sep = "\r\n\r\n".toByteArray(Charsets.ISO_8859_1)
        var gotPin = ""
        var fileName: String? = null
        var fileData: ByteArray? = null
        var pos = indexOf(body, delim, 0)
        while (pos >= 0) {
            val start = pos + delim.size
            if (start + 2 <= body.size && body[start] == '-'.code.toByte() && body[start + 1] == '-'.code.toByte()) break
            val next = indexOf(body, delim, start)
            if (next < 0) break
            val hEnd = indexOf(body, sep, start)
            if (hEnd in 0 until next) {
                val hdr = String(body, start, hEnd - start, Charsets.UTF_8)
                val dataStart = hEnd + sep.size
                val dataEnd = next - 2 // əvvəlki \r\n
                if (dataEnd >= dataStart) {
                    val name = Regex("name=\"([^\"]*)\"").find(hdr)?.groupValues?.get(1)
                    val fn = Regex("filename=\"([^\"]*)\"").find(hdr)?.groupValues?.get(1)
                    val bytes = body.copyOfRange(dataStart, dataEnd)
                    if (name == "pin") gotPin = String(bytes, Charsets.UTF_8).trim()
                    else if (name == "file" && !fn.isNullOrEmpty()) {
                        fileName = fn
                        fileData = bytes
                    }
                }
            }
            pos = next
        }
        if (gotPin != pin) return "PIN səhvdir."
        val fn = fileName ?: return "Fayl seçilməyib."
        val data = fileData ?: return "Fayl boşdur."
        val safe = fn.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
        val ext = safe.substringAfterLast('.', "").lowercase()
        if (ext !in allowedExt) return "Yalnız mp3/wav/ogg/m4a/aac olar."
        dir.mkdirs()
        File(dir, safe).writeBytes(data)
        onChange()
        return "Yükləndi: $safe"
    }

    private fun page(message: String): String {
        val ok = message.startsWith("Yükləndi")
        val msgHtml = if (message.isEmpty()) "" else
            "<div class=\"msg ${if (ok) "ok" else "err"}\">${message.replace("<", "&lt;")}</div>"
        return """
<!doctype html><html lang="az"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#17120E">
<title>FiFa</title>
<style>
*{box-sizing:border-box}
body{margin:0;font-family:Roboto,system-ui,sans-serif;background:#17120E;color:#ECE0D9}
.wrap{max-width:440px;margin:0 auto;padding:24px 16px}
h1{font-size:24px;font-weight:500;margin:8px 0 4px}
p.sub{color:#D5C3B5;margin:0 0 20px;font-size:14px}
.card{background:#2F2924;border-radius:24px;padding:20px}
label{display:block;font-size:13px;color:#D5C3B5;margin:0 0 6px 4px}
input[type=text],input[inputmode]{width:100%;font-size:20px;padding:14px 16px;border-radius:12px;
 border:1px solid #9E8E81;background:transparent;color:#ECE0D9;outline:none;letter-spacing:4px}
input:focus{border:2px solid #FFB868}
.file{display:block;margin:16px 0;padding:18px;border:2px dashed #9E8E81;border-radius:16px;text-align:center;
 color:#D5C3B5;cursor:pointer}
.file input{display:none}
.file b{color:#FFB868}
button{width:100%;font-size:16px;font-weight:500;padding:16px;border:0;border-radius:100px;
 background:#FFB868;color:#4A2800;cursor:pointer}
.msg{padding:14px 16px;border-radius:12px;margin-bottom:16px;font-weight:500}
.ok{background:#2E4A2A;color:#C7EFB9}.err{background:#93000A;color:#FFDAD6}
</style></head><body><div class="wrap">
<h1>Səs yüklə</h1>
<p class="sub">MP3/WAV/OGG/M4A/AAC · maks 40 MB</p>
$msgHtml
<form class="card" method="post" action="/upload" enctype="multipart/form-data">
<label>PIN (monitorda göstərilir)</label>
<input name="pin" inputmode="numeric" autocomplete="off" maxlength="4">
<label class="file"><input type="file" name="file" accept="audio/*"
 onchange="document.getElementById('fn').textContent=this.files[0]?this.files[0].name:'Fayl seç'">
<b id="fn">Fayl seç</b></label>
<button type="submit">Yüklə</button>
</form></div></body></html>""".trimIndent()
    }

    private fun respond(out: OutputStream, code: Int, html: String) {
        val b = html.toByteArray(Charsets.UTF_8)
        val status = when (code) { 200 -> "OK"; 400 -> "Bad Request"; else -> "Not Found" }
        out.write(
            ("HTTP/1.1 $code $status\r\nContent-Type: text/html; charset=utf-8\r\n" +
                "Content-Length: ${b.size}\r\nConnection: close\r\n\r\n").toByteArray()
        )
        out.write(b)
        out.flush()
    }
}
