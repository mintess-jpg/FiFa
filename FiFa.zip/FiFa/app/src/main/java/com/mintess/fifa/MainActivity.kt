package com.mintess.fifa

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import java.io.File
import java.net.NetworkInterface
import java.util.Locale
import kotlin.math.max
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PREFS = "fifa"
        private const val K_DEVICE = "device_key"
        private const val K_LOOP = "loop"
        private const val K_BOOST = "boost_db"
        private const val DEFAULT_BOOST_DB = 10
        private const val DEFAULT_USAGE = "ALARM" // hər açılışda ALARM

        // Safe zone: ekran kənarlarından boşluq (ekran ölçüsünün faizi).
        // Status bar / sistem zolaqlarının hündürlüyü üstünə əlavə olunur,
        // yuxarı və aşağı boşluq HƏMİŞƏ bərabərdir.
        // Kənarlar kəsilirsə bu rəqəmləri artırın (məs. 0.07f).
        private const val SAFE_V = 0.045f
        private const val SAFE_H = 0.05f
    }

    private lateinit var audio: AudioManager
    private lateinit var prefs: SharedPreferences
    private lateinit var soundsDir: File

    private lateinit var outer: FrameLayout
    private lateinit var root: LinearLayout
    private lateinit var nowPlaying: TextView
    private lateinit var stopBtn: MaterialButton
    private lateinit var progress: LinearProgressIndicator
    private lateinit var deviceDropdown: MaterialAutoCompleteTextView
    private lateinit var usageGroup: ChipGroup
    private lateinit var boostSlider: Slider
    private lateinit var boostValue: TextView
    private lateinit var loopSwitch: MaterialSwitch
    private lateinit var serverSwitch: MaterialSwitch
    private lateinit var serverUrl: TextView
    private lateinit var pinText: TextView
    private lateinit var serverStatus: TextView
    private lateinit var soundsTitle: TextView
    private lateinit var emptyText: TextView
    private lateinit var listBox: LinearLayout

    private var insetL = 0
    private var insetT = 0
    private var insetR = 0
    private var insetB = 0

    private var devices: List<AudioDeviceInfo> = emptyList()
    private var selectedDevice = 0 // 0 = avtomatik
    private var player: BoostPlayer? = null
    private var playingFile: File? = null
    private var server: UploadServer? = null
    private val pin = Random.nextInt(1000, 9999).toString()

    private val usages = linkedMapOf(
        "ALARM" to AudioAttributes.USAGE_ALARM,
        "MEDIA" to AudioAttributes.USAGE_MEDIA,
        "NOTIFICATION" to AudioAttributes.USAGE_NOTIFICATION,
        "NAVIGATION" to AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE,
        "ASSISTANT" to AudioAttributes.USAGE_ASSISTANT,
        "GAME" to AudioAttributes.USAGE_GAME
    )
    private var usageName = DEFAULT_USAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        soundsDir = File(filesDir, "sounds").also { it.mkdirs() }
        setContentView(R.layout.activity_main)
        bindViews()
        setupSafeZone()
        applyColumns()
        wire()
        refreshDevices()
        refreshList()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyColumns()
        outer.post { applySafeZone() }
    }

    // ---------- UI ----------

    private fun bindViews() {
        outer = findViewById(R.id.outer)
        root = findViewById(R.id.root)
        nowPlaying = findViewById(R.id.nowPlaying)
        stopBtn = findViewById(R.id.stopBtn)
        progress = findViewById(R.id.progress)
        deviceDropdown = findViewById(R.id.deviceDropdown)
        usageGroup = findViewById(R.id.usageGroup)
        boostSlider = findViewById(R.id.boostSlider)
        boostValue = findViewById(R.id.boostValue)
        loopSwitch = findViewById(R.id.loopSwitch)
        serverSwitch = findViewById(R.id.serverSwitch)
        serverUrl = findViewById(R.id.serverUrl)
        pinText = findViewById(R.id.pinText)
        serverStatus = findViewById(R.id.serverStatus)
        soundsTitle = findViewById(R.id.soundsTitle)
        emptyText = findViewById(R.id.emptyText)
        listBox = findViewById(R.id.listBox)
    }

    /** Sistem zolaqlarını (status bar və s.) öyrənib məzmunu ortaya yığır. */
    private fun setupSafeZone() {
        ViewCompat.setOnApplyWindowInsetsListener(outer) { _, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            insetL = b.left; insetT = b.top; insetR = b.right; insetB = b.bottom
            applySafeZone()
            insets
        }
        outer.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or_, ob ->
            if (r - l != or_ - ol || b - t != ob - ot) outer.post { applySafeZone() }
        }
    }

    private fun applySafeZone() {
        val w = outer.width
        val h = outer.height
        if (w == 0 || h == 0) return
        // Yuxarı və aşağı eyni: ən böyük sistem zolağı + faiz boşluğu
        val v = max(insetT, insetB) + (h * SAFE_V).toInt()
        val s = max(insetL, insetR) + (w * SAFE_H).toInt()
        val lp = root.layoutParams as FrameLayout.LayoutParams
        if (lp.topMargin == v && lp.bottomMargin == v && lp.leftMargin == s && lp.rightMargin == s) return
        lp.width = FrameLayout.LayoutParams.MATCH_PARENT
        lp.height = FrameLayout.LayoutParams.MATCH_PARENT
        lp.setMargins(s, v, s, v)
        root.layoutParams = lp
    }

    /** Geniş ekranda iki sütun, dar ekranda bir sütun. */
    private fun applyColumns() {
        val leftCol = findViewById<LinearLayout>(R.id.leftCol)
        val rightCol = findViewById<LinearLayout>(R.id.rightCol)
        val rightScroll = findViewById<ScrollView>(R.id.rightScroll)
        val soundsCard = findViewById<MaterialCardView>(R.id.soundsCard)
        val wide = resources.configuration.screenWidthDp >= 640
        (soundsCard.parent as? LinearLayout)?.removeView(soundsCard)
        if (wide) {
            rightCol.addView(soundsCard)
            rightScroll.visibility = View.VISIBLE
        } else {
            leftCol.addView(soundsCard, 0)
            rightScroll.visibility = View.GONE
        }
    }

    private fun wire() {
        // Səs rejimi — hər açılışda ALARM
        usageName = DEFAULT_USAGE
        for (i in 0 until usageGroup.childCount) {
            val c = usageGroup.getChildAt(i) as? Chip ?: continue
            c.isChecked = c.tag == usageName
        }
        usageGroup.setOnCheckedStateChangeListener { group, ids ->
            val chip = ids.firstOrNull()?.let { group.findViewById<Chip>(it) }
                ?: return@setOnCheckedStateChangeListener
            usageName = chip.tag as String
            updateNowPlaying()
        }

        // Boost (yadda qalır)
        val savedBoost = prefs.getInt(K_BOOST, DEFAULT_BOOST_DB).coerceIn(0, 30)
        boostSlider.value = savedBoost.toFloat()
        boostValue.text = boostText(savedBoost)
        boostSlider.setLabelFormatter { boostText(it.toInt()) }
        boostSlider.addOnChangeListener { _, v, _ ->
            val db = v.toInt()
            boostValue.text = boostText(db)
            prefs.edit().putInt(K_BOOST, db).apply()
            player?.setBoostDb(v)
        }

        // Loop (yadda qalır)
        loopSwitch.isChecked = prefs.getBoolean(K_LOOP, false)
        loopSwitch.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean(K_LOOP, on).apply()
            player?.looping = on
        }

        // Çıxış (yadda qalır)
        deviceDropdown.setOnItemClickListener { _, _, pos, _ ->
            selectedDevice = pos
            prefs.edit().putString(K_DEVICE, if (pos == 0) "" else keyOf(devices[pos - 1])).apply()
        }
        findViewById<MaterialButton>(R.id.refreshBtn).setOnClickListener {
            refreshDevices()
            toast("Çıxışlar yeniləndi (${devices.size})")
        }

        stopBtn.setOnClickListener { stopPlayback() }
        serverSwitch.setOnCheckedChangeListener { _, on -> setServer(on) }
        updateNowPlaying()
    }

    private fun boostText(db: Int) = if (db <= 0) "Söndürülüb" else "+$db dB"

    private fun toast(msg: String) {
        Snackbar.make(root, msg, Snackbar.LENGTH_LONG).show()
    }

    // ---------- Çıxış cihazları ----------

    private fun typeName(t: Int): String = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "builtin speaker"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "earpiece"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "bluetooth a2dp"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "bluetooth sco"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "wired headphones"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "wired headset"
        AudioDeviceInfo.TYPE_USB_DEVICE -> "usb device"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "usb headset"
        AudioDeviceInfo.TYPE_LINE_ANALOG -> "line analog"
        AudioDeviceInfo.TYPE_AUX_LINE -> "aux line"
        AudioDeviceInfo.TYPE_BUS -> "bus"
        AudioDeviceInfo.TYPE_TELEPHONY -> "telephony"
        else -> "type $t"
    }

    private fun addrOf(d: AudioDeviceInfo) = if (Build.VERSION.SDK_INT >= 28) d.address ?: "" else ""

    private fun keyOf(d: AudioDeviceInfo) = "${d.type}|${d.productName}|${addrOf(d)}"

    private fun refreshDevices() {
        devices = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        val names = mutableListOf("Avtomatik (default)")
        names += devices.map { d ->
            val addr = addrOf(d)
            "${d.productName} · ${typeName(d.type)} · id ${d.id}" + (if (addr.isNotEmpty()) " · $addr" else "")
        }
        deviceDropdown.setSimpleItems(names.toTypedArray())
        val savedKey = prefs.getString(K_DEVICE, "") ?: ""
        selectedDevice = if (savedKey.isEmpty()) 0
        else devices.indexOfFirst { keyOf(it) == savedKey }.let { if (it >= 0) it + 1 else 0 }
        deviceDropdown.setText(names[selectedDevice], false)
    }

    // ---------- Səs siyahısı ----------

    private fun sizeText(bytes: Long): String =
        if (bytes >= 1024 * 1024) String.format(Locale.US, "%.1f MB", bytes / 1048576.0)
        else "${(bytes / 1024).coerceAtLeast(1)} KB"

    private fun refreshList() {
        listBox.removeAllViews()
        val files = soundsDir.listFiles()?.filter { it.isFile }?.sortedBy { it.name.lowercase() } ?: emptyList()
        soundsTitle.text = if (files.isEmpty()) "Səslər" else "Səslər (${files.size})"
        emptyText.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE

        val inflater = LayoutInflater.from(this)
        val density = resources.displayMetrics.density
        for (f in files) {
            val item = inflater.inflate(R.layout.item_sound, listBox, false) as MaterialCardView
            val isPlaying = player != null && playingFile?.absolutePath == f.absolutePath
            item.findViewById<TextView>(R.id.name).text = f.name
            item.findViewById<TextView>(R.id.meta).text =
                sizeText(f.length()) + (if (isPlaying) "  ·  oxunur" else "")
            item.findViewById<ImageView>(R.id.icon)
                .setImageResource(if (isPlaying) R.drawable.ic_stop else R.drawable.ic_play)
            if (isPlaying) {
                item.strokeColor = getColor(R.color.playing_stroke)
                item.strokeWidth = (2 * density).toInt()
                item.setCardBackgroundColor(getColor(R.color.playing_bg))
            }
            item.setOnClickListener { if (isPlaying) stopPlayback() else play(f) }
            item.findViewById<MaterialButton>(R.id.del).setOnClickListener {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Silinsin?")
                    .setMessage(f.name)
                    .setNegativeButton("Ləğv et", null)
                    .setPositiveButton("Sil") { _, _ ->
                        if (playingFile?.absolutePath == f.absolutePath) stopPlayback()
                        f.delete()
                        refreshList()
                    }
                    .show()
            }
            listBox.addView(item)
        }
    }

    // ---------- Oxutma ----------

    private fun play(f: File) {
        stopPlayback(refresh = false)
        val usage = usages[usageName] ?: AudioAttributes.USAGE_ALARM
        val attrs = AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val dev = if (selectedDevice > 0) devices.getOrNull(selectedDevice - 1) else null
        lateinit var p: BoostPlayer
        p = BoostPlayer(
            file = f,
            attributes = attrs,
            device = dev,
            looping = loopSwitch.isChecked,
            boostDb = boostSlider.value,
            onProgress = { pos, dur ->
                if (player === p && dur > 0) {
                    progress.setProgressCompat(((pos % dur) * 1000 / dur).toInt(), true)
                    if (!p.routedOk) toastOnce("Bu çıxışa yönləndirmək alınmadı (ok=false)")
                }
            },
            onFinished = { err ->
                if (player === p) {
                    if (err != null) toast("Oxuma xətası: $err")
                    stopPlayback()
                }
            }
        )
        player = p
        playingFile = f
        routeWarned = false
        p.start()
        progress.setProgressCompat(0, false)
        progress.visibility = View.VISIBLE
        updateNowPlaying()
        refreshList()
    }

    private var routeWarned = false
    private fun toastOnce(msg: String) {
        if (!routeWarned) { routeWarned = true; toast(msg) }
    }

    private fun stopPlayback(refresh: Boolean = true) {
        val p = player
        player = null
        playingFile = null
        p?.stop()
        progress.visibility = View.INVISIBLE
        updateNowPlaying()
        if (refresh && p != null) refreshList()
    }

    private fun updateNowPlaying() {
        val f = playingFile
        nowPlaying.text = if (f != null && player != null) "▶ ${f.name}  ·  $usageName" else "Hazırdır  ·  $usageName"
        stopBtn.isEnabled = player != null
    }

    // ---------- Server ----------

    private fun setServer(on: Boolean) {
        if (on) {
            if (server?.running == true) return
            try {
                server = UploadServer(soundsDir, pin) { runOnUiThread { refreshList() } }
                server!!.start(8080)
                serverUrl.text = "http://${localIp()}:8080"
                serverUrl.visibility = View.VISIBLE
                pinText.text = "PIN: $pin"
                pinText.visibility = View.VISIBLE
                serverStatus.text = "Telefonda brauzerdə bu ünvanı aç. Telefon və monitor eyni Wi-Fi/hotspot-da olmalıdır."
            } catch (e: Exception) {
                server = null
                serverStatus.text = "Server açılmadı: ${e.message}"
                serverSwitch.isChecked = false
            }
        } else {
            server?.stop()
            server = null
            serverUrl.visibility = View.GONE
            pinText.visibility = View.GONE
            serverStatus.text = "Server söndürülüb"
        }
    }

    private fun localIp(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (ni.isLoopback || !ni.isUp) continue
                for (a in ni.inetAddresses) {
                    val h = a.hostAddress ?: continue
                    if (!a.isLoopbackAddress && !h.contains(':')) return h
                }
            }
        } catch (_: Exception) {}
        return "?.?.?.?"
    }

    override fun onDestroy() {
        stopPlayback(refresh = false)
        server?.stop()
        super.onDestroy()
    }
}
